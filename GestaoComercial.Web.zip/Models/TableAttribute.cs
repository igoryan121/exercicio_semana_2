﻿using System;

namespace $safeprojectname$.Models
{
    internal class TableAttribute : Attribute
    {
    }
}